package states;

import javafx.scene.paint.Color;
import javafx.scene.Node;
import ca.udes.model.Polygone;
import ca.udes.model.Arrow;

public interface EMRState {
	
	public void drawArrow();
	public void drawShape();
	
}
