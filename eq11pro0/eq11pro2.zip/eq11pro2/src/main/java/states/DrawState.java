package states;

import ca.udes.controlleurs.Controller;
import javafx.scene.paint.Color;
import javafx.scene.Node;

public class DrawState implements EMRState {
	
	@Override
	public void drawArrow() {
		System.out.println("You can't draw an arrow");
	}
	@Override
	public void drawShape() {
		
	}
	
}
