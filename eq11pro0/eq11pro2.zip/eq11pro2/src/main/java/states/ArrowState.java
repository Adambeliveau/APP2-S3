package states;
import ca.udes.controlleurs.Controller;
import javafx.scene.paint.Color;
import javafx.scene.Node;

public class ArrowState implements EMRState{
	
	@Override
	public void drawArrow() {
	}
	@Override
	public void drawShape() {
		System.out.println("You can't draw a shape");
	}
}
