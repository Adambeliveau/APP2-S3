package ca.udes.model;

public class Rect {

}
